import 'package:flutter_test/flutter_test.dart';
import 'package:client/main.dart';

void main() {
  testWidgets('shows the VIRA connection form', (tester) async {
    await tester.pumpWidget(const ViraApp());
    expect(find.text('VIRA'), findsOneWidget);
    expect(find.text('Connect'), findsOneWidget);
    expect(find.text('Server URL'), findsOneWidget);
  });
}
