import 'dart:convert';

import 'package:http/http.dart' as http;

import 'http_client.dart';

class ViraException implements Exception {
  ViraException(this.message, this.statusCode);
  final String message;
  final int statusCode;
  @override
  String toString() => message;
}

class ViraApi {
  ViraApi(String baseUrl)
    : baseUrl = _normalizeBaseUrl(baseUrl),
      _client = createHttpClient();
  final String baseUrl;
  final http.Client _client;
  String? _cookie;
  String? householdId;

  static String _normalizeBaseUrl(String value) {
    var normalized = value.trim();
    if (!normalized.contains('://')) {
      normalized = 'http://$normalized';
    }
    final uri = Uri.parse(normalized);
    if (uri.scheme == 'https' &&
        (uri.host == 'localhost' || uri.host == '127.0.0.1') &&
        (uri.port == 443 || uri.port == 8000)) {
      return uri
          .replace(scheme: 'http', port: uri.port == 443 ? 8000 : uri.port)
          .toString()
          .replaceFirst(RegExp(r'/$'), '');
    }
    return normalized.replaceFirst(RegExp(r'/$'), '');
  }

  Future<dynamic> _request(
    String method,
    String path, {
    Object? body,
    bool authenticated = true,
    String? idempotencyKey,
  }) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'X-Vira-Client': 'flutter/1.0.0 proto/1',
    };
    if (idempotencyKey != null) {
      headers['Idempotency-Key'] = idempotencyKey;
    }
    if (_cookie != null && authenticated) addCookieHeader(headers, _cookie!);
    final request = http.Request(method, Uri.parse('$baseUrl$path'))
      ..headers.addAll(headers);
    if (body != null) request.body = jsonEncode(body);
    final response = await _client.send(request);
    final text = await response.stream.bytesToString();
    // Browsers manage cookies themselves and intentionally hide Set-Cookie.
    // Native targets expose it, so retain it for the next authenticated call.
    final setCookie = response.headers['set-cookie'];
    if (setCookie != null) _cookie = setCookie.split(';').first;
    final decoded = text.isEmpty ? <String, dynamic>{} : jsonDecode(text);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final detail = decoded is Map ? decoded['detail'] : null;
      throw ViraException(
        detail?.toString() ?? 'Request failed',
        response.statusCode,
      );
    }

    return decoded;
  }

  Future<void> login(String username, String password) async {
    await _request(
      'POST',
      '/api/v1/auth/login',
      body: {'username': username, 'password': password},
      authenticated: false,
    );
  }

  Future<Map<String, dynamic>> currentUser() async =>
      Map<String, dynamic>.from(await _request('GET', '/api/v1/auth/me'));

  Future<Map<String, dynamic>> config() async => Map<String, dynamic>.from(
    await _request('GET', '/api/v1/client-config', authenticated: false),
  );

  Future<List<Map<String, dynamic>>> households() async {
    final result = Map<String, dynamic>.from(
      await _request('GET', '/api/v1/households'),
    );
    return (result['items'] as List)
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
  }

  Future<List<Map<String, dynamic>>> changes({int cursor = 0}) async {
    if (householdId == null) {
      throw StateError('Select a household before syncing');
    }
    final result = Map<String, dynamic>.from(
      await _request(
        'GET',
        '/api/v1/sync/changes?household_id=$householdId&cursor=$cursor',
      ),
    );
    return (result['changes'] as List)
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
  }

  Future<void> saveNote(String id, String title, String body) async {
    if (householdId == null) {
      throw StateError('Select a household before saving');
    }
    await _request(
      'POST',
      '/api/v1/sync/push',
      body: {
        'household_id': householdId,
        'ops': [
          {
            'op_id': id,
            'entity_type': 'note',
            'entity_id': id,
            'op': 'upsert',
            'base_version': 0,
            'data': {
              'id': id,
              'title': title,
              'body_md': body,
              'pinned': false,
            },
          },
        ],
      },
    );
  }

  Future<Map<String, dynamic>> chat(String message) async {
    final idempotencyKey =
        'flutter-${DateTime.now().toUtc().microsecondsSinceEpoch}-${message.hashCode}';
    final result = await _request(
      'POST',
      '/chat',
      body: {'message': message},
      idempotencyKey: idempotencyKey,
    );
    return Map<String, dynamic>.from(result as Map);
  }

  Future<Map<String, dynamic>> orchestration() async =>
      Map<String, dynamic>.from(await _request('GET', '/orchestration'));

  Future<Map<String, dynamic>> health() async =>
      Map<String, dynamic>.from(await _request('GET', '/health'));

  Future<Map<String, dynamic>> agents() async =>
      Map<String, dynamic>.from(await _request('GET', '/agents'));

  Future<Map<String, dynamic>> workspace() async =>
      Map<String, dynamic>.from(await _request('GET', '/api/v1/workspace'));

  Future<List<Map<String, dynamic>>> devices() async {
    final result = Map<String, dynamic>.from(
      await _request('GET', '/api/v1/devices'),
    );
    final items = result['devices'] ?? result['items'] ?? [];
    return (items as List)
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
  }

  Future<List<Map<String, dynamic>>> users() async {
    final result = Map<String, dynamic>.from(
      await _request('GET', '/api/v1/admin/users'),
    );
    return (result['users'] as List? ?? [])
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
  }

  Future<Map<String, dynamic>> createUser({
    required String username,
    required String role,
    String? password,
  }) async {
    final result = await _request(
      'POST',
      '/api/v1/admin/users',
      body: {
        'username': username,
        'role': role,
        if (password != null && password.isNotEmpty) 'password': password,
      },
    );
    return Map<String, dynamic>.from(result as Map);
  }

  Future<void> updateUser(String userId, {String? role, String? status}) async {
    final body = <String, dynamic>{};
    if (role != null) body['role'] = role;
    if (status != null) body['status'] = status;
    await _request('PATCH', '/api/v1/admin/users/$userId', body: body);
  }

  Future<void> logout() async {
    await _request('POST', '/api/v1/auth/logout', authenticated: false);
    _cookie = null;
  }
}
