import 'package:http/browser_client.dart';
import 'package:http/http.dart' as http;

http.Client createHttpClient() => BrowserClient()..withCredentials = true;

void addCookieHeader(Map<String, String> headers, String cookie) {}
