import 'package:flutter/material.dart';

import 'vira_api.dart';

void main() => runApp(const ViraApp());

class ViraApp extends StatelessWidget {
  const ViraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VIRA',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      useMaterial3: true,
    ),
    home: const ConnectionPage(),
  );
}

class ConnectionPage extends StatefulWidget {
  const ConnectionPage({super.key});
  @override
  State<ConnectionPage> createState() => _ConnectionPageState();
}

class _ConnectionPageState extends State<ConnectionPage> {
  final _server = TextEditingController(text: 'http://localhost:8000');
  final _username = TextEditingController();
  final _password = TextEditingController();
  String? _error;
  bool _busy = false;

  Future<void> _connect() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final api = ViraApi(_server.text.trim());
      await api.login(_username.text.trim(), _password.text);
      if (!mounted) return;
      Navigator.of(
        context,
      ).pushReplacement(MaterialPageRoute(builder: (_) => HomePage(api: api)));
    } on Object catch (error) {
      setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('VIRA', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 8),
              const Text('Connect to your private VIRA server.'),
              const SizedBox(height: 24),
              TextField(
                controller: _server,
                decoration: const InputDecoration(labelText: 'Server URL'),
              ),
              TextField(
                controller: _username,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password'),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    _error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _busy ? null : _connect,
                child: Text(_busy ? 'Connecting…' : 'Connect'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

enum WorkspacePage { dashboard, chat, agents, notes, devices, settings, users }

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.api});
  final ViraApi api;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  WorkspacePage _page = WorkspacePage.dashboard;
  Map<String, dynamic>? _health;
  Map<String, dynamic>? _orchestration;
  Map<String, dynamic>? _workspace;
  List<Map<String, dynamic>> _agents = [];
  List<Map<String, dynamic>> _devices = [];
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _notes = [];
  String? _loadError;
  bool _loading = true;
  final _chat = TextEditingController();
  String _answer = '';
  String? _username;
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    _loadWorkspace();
  }

  Future<void> _loadWorkspace() async {
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      final user = await widget.api.currentUser();
      final roles = (user['roles'] as List? ?? []).map(
        (role) => role.toString(),
      );
      final isAdmin = roles.contains('admin');
      final results = isAdmin
          ? await Future.wait([
              widget.api.health(),
              widget.api.orchestration(),
              widget.api.agents(),
              widget.api.devices(),
              widget.api.users(),
            ])
          : <dynamic>[
              await widget.api.workspace(),
              null,
              <dynamic>[],
              <dynamic>[],
              <dynamic>[],
            ];
      final homes = await widget.api.households();
      if (homes.isNotEmpty) {
        widget.api.householdId = homes.first['id'] as String;
        final changes = await widget.api.changes();
        _notes = changes
            .where((item) => item['op'] == 'upsert')
            .map((item) => Map<String, dynamic>.from(item['data'] as Map))
            .toList();
      }
      if (!mounted) return;
      setState(() {
        _username = user['username']?.toString();
        _isAdmin = isAdmin;
        _health = results[0] as Map<String, dynamic>?;
        _orchestration = results[1] as Map<String, dynamic>?;
        _agents = isAdmin
            ? (((results[2] as Map<String, dynamic>)['loaded'] as List?) ?? [])
                  .map((item) => Map<String, dynamic>.from(item as Map))
                  .toList()
            : <Map<String, dynamic>>[];
        _workspace = isAdmin ? null : results[0] as Map<String, dynamic>;
        if (!isAdmin) {
          _health = _workspace?['server'] as Map<String, dynamic>?;
          _orchestration = {
            'scheduler': _workspace?['scheduler'] ?? {},
            'agents': _workspace?['agents'] ?? [],
          };
          _agents = (_workspace?['agents'] as List? ?? [])
              .map((item) => Map<String, dynamic>.from(item as Map))
              .toList();
        }
        _devices = (results[3] as List? ?? [])
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        _users = (results[4] as List? ?? [])
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        _loading = false;
      });
    } on Object catch (error) {
      if (mounted) {
        setState(() {
          _loading = false;
          _loadError = error.toString();
        });
      }
    }
  }

  Future<void> _sendChat() async {
    if (_chat.text.trim().isEmpty) return;
    final message = _chat.text.trim();
    setState(() => _answer = 'Thinking…');
    try {
      final result = await widget.api.chat(message);
      setState(() {
        _answer = (result['response'] ?? result['message'] ?? '').toString();
        _chat.clear();
      });
    } on Object catch (error) {
      setState(() => _answer = 'Unable to reach VIRA: $error');
    }
  }

  Future<void> _logout() async {
    await widget.api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const ConnectionPage()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(_title),
      actions: [
        IconButton(
          tooltip: 'Refresh',
          onPressed: _loading ? null : _loadWorkspace,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    drawer: _drawer(context),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _loadError != null
        ? _errorView()
        : _content(),
  );

  String get _title => switch (_page) {
    WorkspacePage.dashboard => 'Dashboard',
    WorkspacePage.chat => 'Talk to Chatbot',
    WorkspacePage.agents => 'Running Agents',
    WorkspacePage.notes => 'Family Notes',
    WorkspacePage.devices => 'Devices',
    WorkspacePage.users => 'Users',
    WorkspacePage.settings => 'Settings',
  };

  Widget _drawer(BuildContext context) {
    final pages = <WorkspacePage>[
      WorkspacePage.dashboard,
      WorkspacePage.chat,
      WorkspacePage.agents,
      WorkspacePage.notes,
      if (_isAdmin) WorkspacePage.devices,
      WorkspacePage.settings,
      if (_isAdmin) WorkspacePage.users,
    ];
    return NavigationDrawer(
      selectedIndex: pages.indexOf(_page),
      onDestinationSelected: (index) {
        setState(() => _page = pages[index]);
        Navigator.pop(context);
      },
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(28, 24, 16, 16),
          child: Text(
            'VIRA Workspace',
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ),
        if (_username != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(28, 0, 16, 16),
            child: Text('Signed in as $_username'),
          ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.dashboard_outlined),
          selectedIcon: Icon(Icons.dashboard),
          label: Text('Dashboard'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.chat_outlined),
          selectedIcon: Icon(Icons.chat),
          label: Text('Talk to Chatbot'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.smart_toy_outlined),
          selectedIcon: Icon(Icons.smart_toy),
          label: Text('Running Agents'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.notes_outlined),
          selectedIcon: Icon(Icons.notes),
          label: Text('Family Notes'),
        ),
        if (_isAdmin)
          const NavigationDrawerDestination(
            icon: Icon(Icons.devices_outlined),
            selectedIcon: Icon(Icons.devices),
            label: Text('Devices'),
          ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.settings_outlined),
          selectedIcon: Icon(Icons.settings),
          label: Text('Settings'),
        ),
        if (_isAdmin)
          const NavigationDrawerDestination(
            icon: Icon(Icons.group_outlined),
            selectedIcon: Icon(Icons.group),
            label: Text('Users'),
          ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout),
          title: const Text('Sign out'),
          onTap: _logout,
        ),
      ],
    );
  }

  Widget _content() => switch (_page) {
    WorkspacePage.dashboard => _dashboard(),
    WorkspacePage.chat => _chatView(),
    WorkspacePage.agents => _agentsView(),
    WorkspacePage.notes => _notesView(),
    WorkspacePage.devices => _devicesView(),
    WorkspacePage.users => _usersView(),
    WorkspacePage.settings => _settingsView(),
  };

  Widget _dashboard() {
    final scheduler = _orchestration?['scheduler'] as Map? ?? {};
    final tools = _orchestration?['tools'] as Map? ?? {};
    return RefreshIndicator(
      onRefresh: _loadWorkspace,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Welcome back${_username == null ? '' : ', $_username'}',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _statCard(
                'Server',
                _health?['status'] ?? 'unknown',
                Icons.dns,
                Colors.green,
              ),
              _statCard(
                'Agents',
                '${_agents.length}',
                Icons.smart_toy,
                Colors.indigo,
              ),
              _statCard(
                'Running tasks',
                '${scheduler['running_tasks'] ?? 0}',
                Icons.autorenew,
                Colors.orange,
              ),
              _statCard(
                'Tools',
                '${tools['total'] ?? 0}',
                Icons.build,
                Colors.teal,
              ),
            ],
          ),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: const Icon(Icons.chat),
              title: const Text('Talk to VIRA'),
              subtitle: const Text(
                'Ask questions and run tasks with your assistant.',
              ),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () => setState(() => _page = WorkspacePage.chat),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.smart_toy),
              title: const Text('View running agents'),
              subtitle: Text('${_agents.length} agents are available'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () => setState(() => _page = WorkspacePage.agents),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) =>
      SizedBox(
        width: 220,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: color.withAlpha(30),
                  foregroundColor: color,
                  child: Icon(icon),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label),
                    Text(value, style: Theme.of(context).textTheme.titleLarge),
                  ],
                ),
              ],
            ),
          ),
        ),
      );

  Widget _agentsView() {
    if (_agents.isEmpty) {
      return const Center(child: Text('No agents are currently loaded.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _agents.length,
      itemBuilder: (_, index) {
        final agent = _agents[index];
        return Card(
          child: ListTile(
            leading: Icon(
              agent['enabled'] == false
                  ? Icons.pause_circle_outline
                  : Icons.smart_toy,
            ),
            title: Text(
              agent['name']?.toString() ??
                  agent['agent_id']?.toString() ??
                  'Agent',
            ),
            subtitle: Text(
              agent['description']?.toString() ?? 'No description',
            ),
            trailing: Chip(
              label: Text(
                agent['state']?.toString() ??
                    (agent['enabled'] == false ? 'disabled' : 'loaded'),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _devicesView() => _devices.isEmpty
      ? const Center(child: Text('No paired devices found.'))
      : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _devices.length,
          itemBuilder: (_, index) {
            final device = _devices[index];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.devices),
                title: Text(device['display_name']?.toString() ?? 'Device'),
                subtitle: Text(
                  '${device['platform'] ?? 'unknown'} · ${device['status'] ?? 'unknown'}',
                ),
                trailing: Text(device['last_seen_at']?.toString() ?? 'Never'),
              ),
            );
          },
        );

  Widget _usersView() => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Server users',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            FilledButton.icon(
              onPressed: _showCreateUser,
              icon: const Icon(Icons.person_add),
              label: const Text('Add user'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Expanded(
          child: _users.isEmpty
              ? const Center(child: Text('No users found.'))
              : ListView.builder(
                  itemCount: _users.length,
                  itemBuilder: (_, index) {
                    final user = _users[index];
                    final active = user['status'] == 'active';
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Text(
                            (user['username']?.toString() ?? '?')[0]
                                .toUpperCase(),
                          ),
                        ),
                        title: Text(user['username']?.toString() ?? 'User'),
                        subtitle: Text(
                          '${user['role'] ?? 'user'} · ${user['status'] ?? 'unknown'}',
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) async {
                            await widget.api.updateUser(
                              user['user_id'].toString(),
                              status: value,
                            );
                            await _loadWorkspace();
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(
                              value: active ? 'disabled' : 'active',
                              child: Text(active ? 'Disable' : 'Enable'),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    ),
  );

  Future<void> _showCreateUser() async {
    final username = TextEditingController();
    final password = TextEditingController();
    var role = 'user';
    final created = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Add VIRA user'),
          content: SizedBox(
            width: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: username,
                  autofocus: true,
                  decoration: const InputDecoration(
                    labelText: 'Name or username',
                    hintText: 'mom, father, son',
                  ),
                ),
                DropdownButtonFormField<String>(
                  initialValue: role,
                  decoration: const InputDecoration(labelText: 'Role'),
                  items: const [
                    DropdownMenuItem(value: 'user', child: Text('User')),
                    DropdownMenuItem(
                      value: 'admin',
                      child: Text('Administrator'),
                    ),
                  ],
                  onChanged: (value) =>
                      setDialogState(() => role = value ?? 'user'),
                ),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password (optional)',
                    helperText: 'Leave blank to generate a temporary password.',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                try {
                  final result = await widget.api.createUser(
                    username: username.text.trim(),
                    role: role,
                    password: password.text,
                  );
                  if (context.mounted) Navigator.pop(context, result);
                } on Object catch (error) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(SnackBar(content: Text(error.toString())));
                  }
                }
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
    username.dispose();
    password.dispose();
    if (created == null || !mounted) return;
    await _loadWorkspace();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('User created'),
        content: SelectableText(
          'Username: ${created['username']}\n'
          'Password: ${created['temporary_password'] ?? 'The password you entered'}\n'
          'Recovery code: ${created['recovery_code'] ?? 'Not returned'}\n\n'
          'Save these credentials now. They are shown only once.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  Widget _notesView() => _notes.isEmpty
      ? const Center(child: Text('No shared notes yet.'))
      : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _notes.length,
          itemBuilder: (_, index) {
            final note = _notes[index];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.note),
                title: Text(note['title']?.toString() ?? 'Untitled'),
                subtitle: Text(note['body_md']?.toString() ?? ''),
              ),
            );
          },
        );

  Widget _chatView() => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Align(
              alignment: Alignment.topLeft,
              child: Text(_answer.isEmpty ? 'Ask VIRA something.' : _answer),
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _chat,
                onSubmitted: (_) => _sendChat(),
                decoration: const InputDecoration(hintText: 'Message VIRA'),
              ),
            ),
            IconButton(onPressed: _sendChat, icon: const Icon(Icons.send)),
          ],
        ),
      ],
    ),
  );

  Widget _settingsView() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const ListTile(
        leading: Icon(Icons.language),
        title: Text('Connected server'),
        subtitle: Text('VIRA local server'),
      ),
      ListTile(
        leading: const Icon(Icons.refresh),
        title: const Text('Refresh workspace data'),
        onTap: _loadWorkspace,
      ),
      ListTile(
        leading: const Icon(Icons.logout),
        title: const Text('Sign out'),
        onTap: _logout,
      ),
    ],
  );

  Widget _errorView() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off, size: 48),
          const SizedBox(height: 12),
          Text(
            'Could not load the VIRA workspace:\n$_loadError',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _loadWorkspace, child: const Text('Retry')),
        ],
      ),
    ),
  );
}
